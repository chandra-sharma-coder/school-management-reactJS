Front End for a school managemant software The basic content of the school management solution system is the school portal through which access to the following facility are made available;

 School dashboard

 School calendar

 Online payment

 Students results

 Subject notebooks / text book

 CBT (computer based test)

 Assignment submition portal

 Live streaming of students well being (MONTESSORI AND NURSERY)

 Chat box for both students, parents and teachers

The portal is divided to four phases;

• Teachers portal phase

• Students portal phase

• Parents portal phase

• Back end portal phase

THE TEACHERS PORTAL PHASE This is where the teacher gets to;

• Upload notes and text notes/books

• Receive assignments

• Mark assignments

• Upload marks

• Have a chat with students and fellow teachers

THE STUDENTS PORTAL PHASE

This is where the students gets to be able to;

• Receive and download notes, text book and assignments

• Submit assignments

• Write CBT

• View results

• Ask questions and make comments

• Have a chat with fellow students and teachers

THE PARENTS PORTAL PHASE

This is where the parent gets to be able to;

• View childs results

• Make comments and complains, also pass across informations that needs to get to his or her child during school hours

• Make school fee payments and other relevant payments

• Monitor the well being of his or her child or children

THE BACK END PORTAL PHASE

This is controlled by the administrative of the school and our web developer where necessary adjustments and inputing are being made for effectiveness and update of the portals.

The CBT examination are being conducted also from the back end portal phase.

This school management solution software comes in different packages and facilities that comes with each package is listed below;

• Basic package

 Schools dashboard

 Students result

• Full package

 Basic package

 Online payment

 Subject notebooks / text books

 Assignment submition

 CBT (Computer Based Test)

 Live streaming for parents

Online classes
