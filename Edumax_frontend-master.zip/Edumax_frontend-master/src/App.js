import React from 'react';

const App = () => (
  <div>Hello From DImeji</div>
)

export default App;
