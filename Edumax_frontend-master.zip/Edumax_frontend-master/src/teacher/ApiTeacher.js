import { API } from "../config";
import queryString from "query-string";